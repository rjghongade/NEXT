import { useState } from 'react'
import './App.css'
import Header from './component/Header'
import FloorPlans from './component/FloorPlans'
import AmenitiesSection from './component/AmenitiesSection'
import ContactUs from './component/ContactUs'
import Footer from './component/Footer'
import MasterLayout from './component/MasterLayout'
import PropertyDetails from './component/PropertyDetails'
import PropertyPrices from './component/PropertyPrices'
import UnitLayouts from './component/UnitLayouts'
import Blogs from './component/Blogs'
import FAQ from './component/FAQ'
import Gallery from './component/Gallary'
import Banks from './component/Banks'
import FloatingButtons from './component/FloatingButtons'
import Location from './component/Location'
import VideoTour from './component/VideoTour'
import ReraInformation from './component/Rera'
import LocationAdvantages from './component/LocationAdvantages'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div>
      <Header />
      <PropertyPrices />
      <PropertyDetails />
      <LocationAdvantages />
      <AmenitiesSection />
      <UnitLayouts />
      <FloorPlans />
      <Location />
      <MasterLayout />
      <ReraInformation />
      <Banks />
      <Gallery />
      <VideoTour />
      <Blogs />
      <FAQ />
      <ContactUs />
      <Footer />
      <FloatingButtons />
    </div>
  )
}

export default App
