const config = {
    SLUG_URL: import.meta.env.VITE_SLUG_URL || "smp-amberwoodrahatani.com",
    API_URL: import.meta.env.VITE_API_URL || "https://www.buyindiahomes.in/api",
  };
  
  export default config;