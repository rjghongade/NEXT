(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_aaf7d535._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_aaf7d535._.js",
  "chunks": [
    "static/chunks/[root of the server]__af84d97d._.css",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_60f9be80._.js",
    "static/chunks/src_component_2022cdfd._.js",
    "static/chunks/node_modules_next_bed51a8d._.js",
    "static/chunks/node_modules_swiper_00c7e98a._.js",
    "static/chunks/node_modules_@headlessui_react_dist_a48187e6._.js",
    "static/chunks/node_modules_framer-motion_dist_es_0fad660f._.js",
    "static/chunks/node_modules_59059b4c._.js"
  ],
  "source": "dynamic"
});
