"use client";

import { useEffect, useState } from "react";

interface Advertisement {
  above_category_1: string | null;
  above_category_1_url: string | null;
  above_category_2: string | null;
  above_category_2_url: string | null;
  above_category_status: string;
}

const Advertisement = () => {
  const [ads, setAds] = useState<Advertisement | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAdvertisements = async () => {
      try {
        const response = await fetch(
          "https://www.buyindiahomes.in/api/advertisement?website=smp-amberwoodrahatani.com"
        );
        if (!response.ok) {
          throw new Error("Failed to fetch advertisements");
        }
        const data = await response.json();
        setAds(data.contact_us);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchAdvertisements();
  }, []);

  if (loading) return <p className="text-center text-gray-500 py-10">Loading advertisements...</p>;
  if (error) return <p className="text-center text-red-500 py-10">Error: {error}</p>;

  return (
    <>
      {ads?.above_category_status === "Show" && (
        <section className="w-full py-10 bg-gradient-to-br from-amber-100 via-white to-amber-300 text-amber-700">
          <div className="max-w-6xl mx-auto px-6">
            {/* Section Title */}
            <h2 className="text-4xl font-extrabold text-center mb-6">
              🏡 Special Offers & Advertisements
            </h2>

            {/* Advertisement Container */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Advertisement 1 */}
              {ads.above_category_1 && ads.above_category_1_url && (
                <a
                  href={ads.above_category_1_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group block overflow-hidden rounded-lg shadow-lg transform hover:scale-105 transition duration-300"
                >
                  <img
                    src={ads.above_category_1}
                    alt="Advertisement 1"
                    className="w-full h-64 object-cover"
                  />
                  <div className="p-4 bg-white text-gray-900 text-center">
                    <p className="text-lg font-semibold group-hover:text-amber-600 transition">Click to Explore</p>
                  </div>
                </a>
              )}

              {/* Advertisement 2 */}
              {ads.above_category_2 && ads.above_category_2_url && (
                <a
                  href={ads.above_category_2_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group block overflow-hidden rounded-lg shadow-lg transform hover:scale-105 transition duration-300"
                >
                  <img
                    src={ads.above_category_2}
                    alt="Advertisement 2"
                    className="w-full h-64 object-cover"
                  />
                  <div className="p-4 bg-white text-gray-900 text-center">
                    <p className="text-lg font-semibold group-hover:text-amber-600 transition">Discover More</p>
                  </div>
                </a>
              )}
            </div>
          </div>
        </section>
      )}
    </>
  );
};

export default Advertisement;
