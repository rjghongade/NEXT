"use client";

import { useEffect, useState } from "react";

interface SocialIcon {
  id: number;
  social_url: string;
  social_icon: string;
  social_order: number;
}

interface FooterData {
  social_icons: SocialIcon[];
  g_setting: {
    logo: string;
    footer_phone: string;
    footer_email: string;
    footer_address: string;
    footer_disclamer: string;
    footer_copyright: string;
  };
}

const Footer = () => {
  const [footerData, setFooterData] = useState<FooterData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchFooter = async () => {
      try {
        const response = await fetch(
          "https://www.buyindiahomes.in/api/footer?website=smp-amberwoodrahatani.com"
        );
        if (!response.ok) {
          throw new Error("Failed to fetch footer data");
        }
        const data = await response.json();
        setFooterData(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchFooter();
  }, []);

  if (loading)
    return <p className="text-center text-gray-500 py-5">Loading Footer...</p>;
  if (error)
    return <p className="text-center text-red-500 py-5">Error: {error}</p>;

  return (
    <footer className="bg-gradient-to-r from-amber-600 to-amber-800 text-white py-10">
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 px-6">
        {/* Left Section - Logo & Contact Info */}
        <div className="flex flex-col items-center md:items-start">
          <img
            src={footerData?.g_setting.logo}
            alt="Company Logo"
            className="h-16 mb-4"
          />
          <p className="text-sm">📍 {footerData?.g_setting.footer_address}</p>
          <p className="text-sm">📞 {footerData?.g_setting.footer_phone}</p>
          <p className="text-sm">✉️ {footerData?.g_setting.footer_email}</p>
        </div>

        {/* Center Section - Social Media Icons */}
        <div className="flex flex-col items-center">
          <h3 className="text-lg font-semibold mb-4">Follow Us</h3>
          <div className="flex space-x-4">
            {footerData?.social_icons
              .sort((a, b) => a.social_order - b.social_order)
              .map((icon) => (
                <a
                  key={icon.id}
                  href={icon.social_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-3xl text-white hover:text-gray-300 transition"
                >
                  <i className={`fab ${icon.social_icon}`}></i>
                </a>
              ))}
          </div>
        </div>

        {/* Right Section - Disclaimer */}
        <div className="text-center md:text-left">
          <h3 className="text-lg font-semibold mb-4">Disclaimer</h3>
          <p className="text-sm">{footerData?.g_setting.footer_disclamer}</p>
        </div>
      </div>

      {/* Copyright Notice */}
      <div className="text-center text-sm mt-8 border-t border-gray-400 pt-4">
        {footerData?.g_setting.footer_copyright}
      </div>
    </footer>
  );
};

export default Footer;
