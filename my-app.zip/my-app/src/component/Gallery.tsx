'use client';
import { useEffect, useState } from 'react';

const Gallery = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);

  useEffect(() => {
    fetch('https://www.buyindiahomes.in/api/gallary?website=smp-amberwoodrahatani.com')
      .then((response) => response.json())
      .then((result) => {
        setData(result);
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, []);

  if (loading)
    return <div className="flex justify-center items-center h-screen text-lg font-semibold text-amber-800">Loading...</div>;

  if (error)
    return <div className="text-center text-red-500 font-semibold py-6">Error fetching data</div>;

  return (
    <div className="bg-gradient-to-br from-amber-100 via-white to-amber-300 min-h-screen py-12">
      <div className="container mx-auto px-6">
        {/* Section Heading */}
        <h2 className="text-4xl font-extrabold text-center text-amber-700 mb-12 relative">
          {data?.page[0]?.heading}
          <span className="block w-24 h-1 bg-amber-700 mx-auto mt-3 rounded-full"></span>
        </h2>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {data?.property_photos.map((photo) => (
            <div 
              key={photo.id} 
              className="overflow-hidden rounded-2xl shadow-md hover:shadow-xl transition-transform transform hover:-translate-y-2 duration-300 relative group"
              onClick={() => setSelectedImage(photo.photo)}
            >
              <img src={photo.photo} alt="Gallery Image" className="w-full h-60 object-cover rounded-2xl group-hover:scale-110 transition-transform duration-300 cursor-pointer" />
              {/* Hover Overlay */}
              <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity duration-300">
                <p className="text-white text-lg font-semibold">View Image</p>
              </div>
            </div>
          ))}
        </div>

        {/* Popup Lightbox */}
        {selectedImage && (
          <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center px-4 z-50">
            <div className="relative w-full max-w-4xl">
              {/* Close Button */}
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute top-4 right-4 text-white text-3xl font-bold cursor-pointer"
              >
                ✖
              </button>
              {/* Full Image */}
              <img src={selectedImage} alt="Selected" className="w-full h-auto rounded-lg shadow-lg" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Gallery;
