"use client";

import { useEffect, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Autoplay } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";

interface UnitLayout {
  id: number;
  layout_name: string;
  layout_image: string;
  unit_layout_heading: string;
  unit_layout_carpet_area: string;
  unit_layout_price: string;
}

const UnitLayouts = () => {
  const [layouts, setLayouts] = useState<UnitLayout[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("https://www.buyindiahomes.in/api/unit-layout?website=smp-amberwoodrahatani.com")
      .then((response) => response.json())
      .then((data) => {
        if (data.unit_layout) {
          setLayouts(data.unit_layout);
        }
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching unit layouts:", error);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div className="flex justify-center items-center h-screen text-xl font-semibold text-white">Loading unit layouts...</div>;
  }

  return (
    <section className="py-16 bg-gradient-to-b from-amber-500 to-amber-700 min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Heading */}
        <h2 className="text-4xl font-extrabold text-center text-white mb-12 relative">
          Unit Layouts
          <span className="block w-20 h-1 bg-amber-900 mx-auto mt-3 rounded-full"></span>
        </h2>

        {/* Swiper Slider */}
        <Swiper
          modules={[Navigation, Autoplay]}
          slidesPerView={1}
          spaceBetween={20}
          navigation
          autoplay={{ delay: 3000, disableOnInteraction: false }}
          breakpoints={{
            640: { slidesPerView: 2 },
            768: { slidesPerView: 3 },
          }}
          className="px-4"
        >
          {layouts.map((layout) => (
            <SwiperSlide key={layout.id}>
              <div className="bg-white/20 backdrop-blur-lg border border-white/30 shadow-lg rounded-2xl overflow-hidden transition transform hover:scale-105 hover:bg-white/30">
                <img
                  src={layout.layout_image}
                  alt={layout.layout_name}
                  className="w-full h-60 object-cover"
                />
                <div className="p-6 text-center">
                  <h3 className="text-2xl font-semibold text-white">{layout.unit_layout_heading}</h3>
                  <p className="text-white mt-2">
                    <strong>Carpet Area:</strong> {layout.unit_layout_carpet_area}
                  </p>
                  <p className="text-white">
                    <strong>Price:</strong> {layout.unit_layout_price}
                  </p>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </section>
  );
};

export default UnitLayouts;
