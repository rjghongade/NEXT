"use client";

import { useEffect, useState } from "react";

interface Testimonial {
  heading: string;
  subheading: string;
}

const TestimonialList = () => {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchTestimonials = async () => {
      try {
        const response = await fetch(
          "https://www.buyindiahomes.in/api/testimonials?website=smp-amberwoodrahatani.com"
        );
        if (!response.ok) {
          throw new Error("Failed to fetch testimonials");
        }
        const data = await response.json();
        setTestimonials(data.page || []);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchTestimonials();
  }, []);

  if (loading) return <p>Loading testimonials...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div className="p-4">
      {testimonials.map((testimonial, index) => (
        <div key={index} className="mb-4 p-4 border rounded shadow-md">
          <h2 className="text-xl font-bold">{testimonial.heading}</h2>
          <p className="text-gray-600">{testimonial.subheading}</p>
        </div>
      ))}
    </div>
  );
};

export default TestimonialList;
