'use client';
import { useEffect, useState } from 'react';

const PropertyPrices = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedProperty, setSelectedProperty] = useState(null);

  useEffect(() => {
    fetch('https://www.buyindiahomes.in/api/property-prices?website=smp-amberwoodrahatani.com')
      .then((response) => response.json())
      .then((result) => {
        setData(result);
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, []);

  if (loading)
    return <div className="flex justify-center items-center h-screen text-lg font-semibold text-amber-800">Loading...</div>;

  if (error)
    return <div className="text-center text-red-500 font-semibold py-6">Error fetching data</div>;

  return (
    <div className="bg-gradient-to-br from-amber-100 via-white to-amber-300 min-h-screen py-12">
      <div className="container mx-auto px-6">
        {/* Section Heading */}
        <h2 className="text-4xl font-extrabold text-center text-amber-700 mb-12 relative">
          {data?.page[0]?.heading}
          <span className="block w-24 h-1 bg-amber-700 mx-auto mt-3 rounded-full"></span>
        </h2>

        {/* Property Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {data?.property_prices.map((property) => (
            <div
              key={property.id}
              className=" shadow-lg rounded-2xl p-6 border border-amber-300 hover:shadow-2xl transition-transform transform hover:-translate-y-2 duration-300"
            >
              <h3 className="text-2xl font-semibold text-amber-700">{property.property_type}</h3>
              <p className="text-gray-600 text-sm mt-1">🏢 Tower: <span className="font-medium text-gray-800">{property.property_tower}</span></p>
              <p className="text-gray-600 text-sm">📏 Carpet Area: <span className="font-medium text-gray-800">{property.property_carpet} {property.carpet_unit}</span></p>
              <div className="mt-4">
                <p className="text-xl font-bold text-amber-700">₹{property.property_price} {property.price_unit}</p>
                <span className="text-sm text-gray-500">({property.price_tag})</span>
              </div>
              <button
                onClick={() => setSelectedProperty(property)}
                className="mt-4 w-full bg-amber-400 text-white py-2 rounded-lg font-semibold hover:bg-amber-600 transition"
              >
                View Details
              </button>
            </div>
          ))}
        </div>

        {/* Popup Modal */}
        {selectedProperty && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center px-4">
            <div className="bg-gradient-to-br from-amber-100 via-white to-amber-300 rounded-xl shadow-lg p-6 w-full max-w-lg relative">
              {/* Close Button */}
              <button
                onClick={() => setSelectedProperty(null)}
                className="absolute top-4 right-4 text-gray-600 hover:text-gray-900 text-xl"
              >
                ✖
              </button>

              <h3 className="text-3xl font-bold text-amber-900">{selectedProperty.property_type} Details</h3>
              <div className="mt-4">
                <p className="text-gray-700 text-lg">🏢 Tower: <span className="font-semibold">{selectedProperty.property_tower}</span></p>
                <p className="text-gray-700 text-lg">📏 Carpet Area: <span className="font-semibold">{selectedProperty.property_carpet} {selectedProperty.carpet_unit}</span></p>
                <p className="text-gray-700 text-lg">💰 Price: <span className="font-semibold text-amber-700">₹{selectedProperty.property_price} {selectedProperty.price_unit}</span></p>
                <p className="text-gray-700 text-lg">📝 Price Tag: <span className="font-semibold">{selectedProperty.price_tag}</span></p>
              </div>

              <button
                onClick={() => setSelectedProperty(null)}
                className="mt-6 w-full bg-amber-500 text-gray-800 py-2 rounded-lg font-semibold hover:bg-amber-400 transition"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PropertyPrices;
