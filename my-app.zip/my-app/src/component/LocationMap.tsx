"use client";

import React, { useEffect, useState } from "react";

interface LocationData {
  heading: string;
  subheading: string | null;
  map: string;
}

const LocationMap: React.FC = () => {
  const [locationData, setLocationData] = useState<LocationData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLocationData = async () => {
      try {
        const response = await fetch(
          "https://www.buyindiahomes.in/api/location-map?website=smp-amberwoodrahatani.com"
        );
        const data = await response.json();
        setLocationData(data);
      } catch (error) {
        console.error("Error fetching location data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchLocationData();
  }, []);

  return (
    <section className="w-full py-16 bg-gradient-to-br from-amber-100 via-white to-amber-300">
      <div className="max-w-6xl mx-auto px-6 text-center">
        {/* Section Heading */}
        <h2 className="text-4xl font-extrabold text-amber-700">{locationData?.heading || "Our Location"}</h2>
        {locationData?.subheading && (
          <p className="text-lg text-amber-700 mt-2 opacity-90">{locationData.subheading}</p>
        )}
      </div>

      {/* Map Container */}
      <div className="mt-10 flex justify-center">
        <div className="w-full max-w-4xl rounded-xl overflow-hidden shadow-xl bg-gradient-to-br from-amber-100 via-white to-amber-300 p-6 border border-amber-600">
          {loading ? (
            <div className="flex justify-center items-center h-72">
              <div className="animate-spin rounded-full h-14 w-14 border-b-4 border-amber-500"></div>
            </div>
          ) : locationData ? (
            <div
              className="w-full h-80 rounded-md overflow-hidden shadow-md border border-amber-600"
              dangerouslySetInnerHTML={{ __html: locationData.map }}
            ></div>
          ) : (
            <div className="text-center text-lg text-red-600 font-semibold">
              Failed to load location map.
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default LocationMap;
