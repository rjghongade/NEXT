'use client';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';

const Slider = () => {
  return (
    <Carousel 
      autoPlay 
      interval={3000} 
      infiniteLoop 
      showThumbs={false} 
      showStatus={false} 
      showIndicators={true} 
      stopOnHover
    >
      <div>
        <img src="/banner.jpg" alt="Banner 1" className="w-full h-auto" />
      </div>
      <div>
        <img src="/banner.jpg" alt="Backdrop Decorations" className="w-full h-auto" />
      </div>
      <div>
        <img src="/banner.jpg" alt="Banner 2" className="w-full h-auto" />
      </div>
    </Carousel>
  );
};

export default Slider;
