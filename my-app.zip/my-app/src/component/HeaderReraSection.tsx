"use client";

import { useEffect, useState } from "react";
import { Building, Calendar, MapPin, FileText, Grid } from "lucide-react";
import Image from "next/image";

interface ReraData {
  id: number;
  property_id: number;
  rera_id: string;
  phase_name: string;
  rera_url: string;
  completion_date: string;
  total_area: number;
  total_acre: number;
  total_tower: number;
  total_units: number;
  created_at: string;
  updated_at: string;
  deleted_at: null | string;
}

interface PageData {
  heading: string;
  subheading: string | null;
}

interface ApiResponse {
  page: PageData[];
  rera: ReraData[];
}

const HeaderReraSection = () => {
  const [data, setData] = useState<ApiResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          "https://www.buyindiahomes.in/api/rera?website=smp-amberwoodrahatani.com"
        );
        if (!response.ok) throw new Error("Failed to fetch RERA data");

        const apiData: ApiResponse = await response.json();
        setData(apiData);
      } catch (err) {
        setError("Unable to fetch RERA information. Please try again later.");
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-IN", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-60">
        <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-amber-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center text-red-600 font-semibold p-6">
        {error}
      </div>
    );
  }

  if (!data || !data.rera || data.rera.length === 0) {
    return <div className="text-center text-gray-500 p-6">No RERA data available</div>;
  }

  const reraInfo = data.rera[0];
  const pageInfo = data.page[0];

  return (
    <>
      <section className="bg-gradient-to-b from-amber-500 to-amber-700 py-12 text-white">
        <div className="container mx-auto px-4">
          {/* Section Header */}
          <div className="text-center mb-10">
            <h2 className="text-4xl font-extrabold relative inline-block uppercase ">
              {pageInfo.heading}
            </h2>
          </div>

          {/* MahaRERA Logo and ID Section */}
          <div className="flex flex-col md:flex-row items-center justify-center gap-8 mb-10">
            <div className="bg-gradient-to-br from-amber-100 via-white to-amber-300 rounded-xl shadow-lg p-6 flex items-center gap-4 w-full max-w-md">
              <div className="flex-shrink-0">
                <Image
                  src="/api/placeholder/120/120"
                  alt="MahaRERA Logo"
                  width={100}
                  height={100}
                  className="rounded-lg"
                />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-amber-800">MahaRERA Registered</h3>
                <p className="text-gray-800 text-sm">Registration ID</p>
                <p className="text-xl font-bold text-amber-900 mt-1">{reraInfo.rera_id}</p>
                <a 
                  href={reraInfo.rera_url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-amber-600 hover:text-amber-800 mt-2 text-sm font-medium"
                >
                  <FileText size={16} className="mr-1" /> 
                  View on MahaRERA Website
                </a>
              </div>
            </div>
          </div>

          {/* RERA Details Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Phase Card */}
            <div className="bg-gradient-to-br from-amber-100 via-white to-amber-300 rounded-xl shadow-md p-6 border-t-4 border-amber-700">
              <div className="flex items-center mb-4">
                <Building size={24} className="text-amber-700 mr-3" />
                <h3 className="text-lg font-semibold text-gray-800">Project Phase</h3>
              </div>
              <p className="text-2xl font-bold text-amber-900">{reraInfo.phase_name}</p>
            </div>

            {/* Completion Date Card */}
            <div className="bg-gradient-to-br from-amber-100 via-white to-amber-300 rounded-xl shadow-md p-6 border-t-4 border-green-600">
              <div className="flex items-center mb-4">
                <Calendar size={24} className="text-green-600 mr-3" />
                <h3 className="text-lg font-semibold text-gray-800">Completion Date</h3>
              </div>
              <p className="text-2xl font-bold text-green-800">{formatDate(reraInfo.completion_date)}</p>
            </div>

            {/* Area Card */}
            <div className="bg-gradient-to-br from-amber-100 via-white to-amber-300 rounded-xl shadow-md p-6 border-t-4 border-amber-500">
              <div className="flex items-center mb-4">
                <MapPin size={24} className="text-amber-500 mr-3" />
                <h3 className="text-lg font-semibold text-gray-800">Total Area</h3>
              </div>
              <p className="text-2xl font-bold text-amber-800">{reraInfo.total_acre} Acres</p>
            </div>

            {/* Towers Card */}
            <div className="bg-gradient-to-br from-amber-100 via-white to-amber-300 rounded-xl shadow-md p-6 border-t-4 border-purple-600">
              <div className="flex items-center mb-4">
                <Grid size={24} className="text-purple-600 mr-3" />
                <h3 className="text-lg font-semibold text-gray-800">Towers</h3>
              </div>
              <p className="text-2xl font-bold text-purple-800">{reraInfo.total_tower}</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default HeaderReraSection;
