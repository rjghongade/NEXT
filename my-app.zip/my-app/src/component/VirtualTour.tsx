'use client';
import { useEffect, useState } from 'react';

const VirtualTour = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch('https://www.buyindiahomes.in/api/video?website=smp-amberwoodrahatani.com')
      .then((response) => response.json())
      .then((result) => {
        setData(result);
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, []);

  if (loading) 
    return <div className="flex justify-center items-center h-screen text-lg font-semibold text-amber-800">Loading...</div>;
  
  if (error) 
    return <div className="text-center text-red-500 font-semibold py-6">Error fetching data</div>;

  return (
    <div className="bg-gradient-to-b from-amber-500 to-amber-700 min-h-screen flex flex-col justify-center items-center py-12 px-4">
      {/* Section Heading */}
      <h2 className="text-4xl font-extrabold text-center text-white mb-12 relative">
        {data?.page?.heading}
        <span className="block w-28 h-1 bg-amber-900 mx-auto mt-3 rounded-full"></span>
      </h2>

      {/* Video Section */}
      <div className="w-full max-w-6xl shadow-2xl rounded-2xl overflow-hidden border-4 border-amber-700">
        {data?.property_videos.map((video) => (
          <iframe
            key={video.id}
            className="w-full h-[80vh] md:h-[90vh] rounded-2xl"
            src={`https://www.youtube.com/embed/${video.youtube_video_id}`}
            title="Virtual Tour"
            frameBorder="0"
            allowFullScreen
          ></iframe>
        ))}
      </div>
    </div>
  );
};

export default VirtualTour;
