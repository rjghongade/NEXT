"use client";
import { useEffect, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Autoplay } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";

const AmenitiesSection = () => {
  const [amenities, setAmenities] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("https://www.buyindiahomes.in/api/amenities?website=smp-amberwoodrahatani.com")
      .then((response) => response.json())
      .then((data) => {
        if (data.amenities && data.amenities.amenities) {
          setAmenities(data.amenities.amenities);
        }
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching amenities:", error);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div className="flex justify-center items-center h-screen text-xl font-semibold text-white">Loading amenities...</div>;
  }

  return (
    <section id="AmenitiesSection" className="py-16 bg-gradient-to-b from-amber-500 to-amber-700">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Heading */}
        <h2 className="text-4xl font-extrabold text-center text-white mb-12 relative">
          Amenities
          <span className="block w-20 h-1 bg-amber-900 mx-auto mt-3 rounded-full"></span>
        </h2>

        {/* Swiper Slider */}
        <Swiper
          modules={[Navigation, Autoplay]}
          slidesPerView={1}
          spaceBetween={20}
          navigation
          autoplay={{ delay: 3000, disableOnInteraction: false }}
          breakpoints={{
            640: { slidesPerView: 2 },
            768: { slidesPerView: 3 },
            1024: { slidesPerView: 4 },
          }}
          className="px-4"
        >
          {amenities.map((amenity) => (
            <SwiperSlide key={amenity.id}>
              <div className="bg-white/20 backdrop-blur-lg border border-white/30 shadow-xl rounded-2xl p-6 flex flex-col items-center transition transform hover:scale-105 hover:bg-white/30">
                <img
                  src={amenity.property_amenities_photo}
                  alt={amenity.amenity_name}
                  className="w-24 h-24 object-cover mb-4 rounded-full border-4 border-white shadow-lg"
                />
                <p className="text-lg font-semibold text-white">{amenity.amenity_name}</p>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </section>
  );
};

export default AmenitiesSection;
