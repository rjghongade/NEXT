"use client";

import { useEffect, useState } from "react";

interface Property {
  id: number;
  property_name: string;
  property_description: string;
  property_type: string;
  property_price: string;
  sub_location: string;
  builder_name: string;
  og_image: string;
  property_map: string;
}

const PropertyListing = () => {
  const [property, setProperty] = useState<Property | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProperty = async () => {
      try {
        const response = await fetch(
          "https://www.buyindiahomes.in/api/get-properties?website=smp-amberwoodrahatani.com"
        );
        if (!response.ok) {
          throw new Error("Failed to fetch property data");
        }
        const data = await response.json();
        if (data.property_details.length > 0) {
          setProperty(data.property_details[0]);
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchProperty();
  }, []);

  if (loading) return <p className="text-center text-gray-500">Loading Property Details...</p>;
  if (error) return <p className="text-center text-red-500">Error: {error}</p>;

  return (
    <div className="container mx-auto p-6">
      {/* Property Image */}
      <div className="flex flex-col md:flex-row items-center gap-6">
        <img
          src={property?.og_image}
          alt={property?.property_name}
          className="w-full md:w-1/2 rounded-lg shadow-lg"
        />

        {/* Property Details */}
        <div className="md:w-1/2">
          <h1 className="text-3xl font-bold">{property?.property_name}</h1>
          <p className="text-lg text-gray-700 mt-2">{property?.property_type}</p>
          <p className="text-xl font-semibold text-green-600 mt-2">₹ {property?.property_price} Cr</p>
          <p className="text-sm text-gray-500 mt-2">📍 {property?.sub_location}</p>
          <p className="text-sm text-gray-500">🏗️ {property?.builder_name}</p>
        </div>
      </div>

      {/* Property Description */}
      <div className="mt-6">
        <h2 className="text-2xl font-semibold mb-2">About the Property</h2>
        <div
          className="text-gray-600 leading-relaxed"
          dangerouslySetInnerHTML={{ __html: property?.property_description || "" }}
        />
      </div>

      {/* Google Map */}
      <div className="mt-6">
        <h2 className="text-2xl font-semibold mb-2">Location Map</h2>
        <div dangerouslySetInnerHTML={{ __html: property?.property_map || "" }} />
      </div>
    </div>
  );
};

export default PropertyListing;
