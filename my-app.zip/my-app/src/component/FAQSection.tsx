"use client";

import { useState, useEffect } from "react";

const FAQSection = () => {
  const [faqs, setFaqs] = useState([]);
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  useEffect(() => {
    fetch("https://www.buyindiahomes.in/api/faq?website=smp-amberwoodrahatani.com")
      .then((res) => res.json())
      .then((data) => {
        setFaqs(data.faqs);
      })
      .catch((err) => console.error("Error fetching FAQ:", err));
  }, []);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-16 bg-gradient-to-b from-amber-500 to-amber-700 text-white">
      <div className="max-w-4xl mx-auto px-6">
        <h2 className="text-4xl font-extrabold text-center mb-8">Frequently Asked Questions</h2>
        {faqs.length > 0 ? (
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={faq.id} className="bg-gradient-to-br from-amber-100 via-white to-amber-300 text-gray-800 rounded-lg shadow-md overflow-hidden">
                <button
                  className="w-full text-left px-6 py-4 font-semibold flex justify-between items-center bg-amber-600 text-white hover:bg-amber-700 transition duration-300"
                  onClick={() => toggleFAQ(index)}
                >
                  {faq.faq_title}
                  <span className={`transform transition-transform duration-300 ${openIndex === index ? "rotate-180" : "rotate-0"}`}>
                    ▼
                  </span>
                </button>
                <div
                  className={`overflow-hidden transition-max-height duration-500 ${
                    openIndex === index ? "max-h-96" : "max-h-0"
                  }`}
                >
                  <div className="p-6 text-gray-700" dangerouslySetInnerHTML={{ __html: faq.faq_content }} />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-lg">Loading FAQs...</p>
        )}
      </div>
    </section>
  );
};

export default FAQSection;
