"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { Dialog } from "@headlessui/react";

interface MasterLayout {
  id: number;
  layout_name: string;
  layout_image: string;
}

const MasterLayout = () => {
  const [masterLayout, setMasterLayout] = useState<MasterLayout | null>(null);
  const [loading, setLoading] = useState(true);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    fetch("https://www.buyindiahomes.in/api/master-layout?website=smp-amberwoodrahatani.com")
      .then((response) => response.json())
      .then((data) => {
        if (data.master_layout && data.master_layout.length > 0) {
          setMasterLayout(data.master_layout[0]); // Get the first master layout
        }
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching master layout:", error);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen bg-gradient-to-b from-amber-500 to-amber-700">
        <div className="animate-pulse bg-white/30 backdrop-blur-md rounded-lg h-56 w-full max-w-lg"></div>
      </div>
    );
  }

  if (!masterLayout) {
    return (
      <div className="text-center text-amber-700 text-xl font-semibold py-16 bg-gradient-to-b from-amber-500 to-amber-700">
        No Master Layout available
      </div>
    );
  }

  return (
    <section className="py-16 bg-gradient-to-br from-amber-100 via-white to-amber-300 min-h-screen">
      <div className="max-w-6xl mx-auto px-6 text-center">
        {/* Section Title */}
        <h2 className="text-4xl font-extrabold text-amber-700 mb-10 relative">
          {masterLayout.layout_name}
          <span className="block w-20 h-1 bg-amber-700 mx-auto mt-3 rounded-full"></span>
        </h2>

        {/* Image with Hover Effect */}
        <div className="flex justify-center">
          <div className="relative group">
            <Image
              src={masterLayout.layout_image}
              alt={masterLayout.layout_name}
              width={900}
              height={700}
              className="rounded-xl shadow-xl cursor-pointer transition-transform duration-300 transform hover:scale-105"
              onClick={() => setIsOpen(true)}
            />
            {/* Overlay Text */}
            <div
              className="absolute inset-0 bg-black bg-opacity-30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer"
              onClick={() => setIsOpen(true)}
            >
              <span className="text-white text-lg font-semibold">Click to Enlarge</span>
            </div>
          </div>
        </div>

        {/* Modal for Full View */}
        <Dialog open={isOpen} onClose={() => setIsOpen(false)} className="fixed inset-0 z-50">
          {/* Dark Overlay */}
          <div className="fixed inset-0 bg-black bg-opacity-70 transition-opacity" onClick={() => setIsOpen(false)}></div>
          
          {/* Modal Content */}
          <div className="fixed inset-0 flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-2xl overflow-hidden max-w-4xl w-full relative">
              {/* Close Button */}
              <button
                className="absolute top-4 right-4 text-gray-600 hover:text-gray-900 text-2xl font-bold"
                onClick={() => setIsOpen(false)}
              >
                ✕
              </button>

              {/* Enlarged Image */}
              <Image
                src={masterLayout.layout_image}
                alt={masterLayout.layout_name}
                width={1400}
                height={1000}
                className="w-full h-auto rounded-lg"
              />
            </div>
          </div>
        </Dialog>
      </div>
    </section>
  );
};

export default MasterLayout;
