"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Menu, X, ChevronDown, Phone, MapPin } from "lucide-react";
import Image from "next/image";

interface ReraData {
  rera_id: string;
  phase_name: string;
  rera_url: string;
  completion_date: string;
  total_area: number;
  total_acre: number;
  total_tower: number;
  total_units: number;
}

interface HeaderData {
  property_name: string;
  logo: string;
  builder_logo: string;
  property_builder_photo: string;
  favicon: string;
  hero_banner_img: {
    desktop: string[];
    mobile: string[];
  };
  hero_banner_heading: string;
  hero_banner_subheading: string;
  location: string;
  sublocation: string;
  builder_name: string;
  property_type_price_range_text: string;
  property_area_min_max: string;
  property_last_updated: string;
}

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [reraData, setReraData] = useState<ReraData | null>(null);
  const [headerData, setHeaderData] = useState<HeaderData | null>(null);
  const [showReraDetails, setShowReraDetails] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const reraResponse = await fetch(
          "https://www.buyindiahomes.in/api/rera?website=smp-amberwoodrahatani.com"
        );
        const reraJson = await reraResponse.json();
        if (reraJson?.rera?.length > 0) {
          setReraData(reraJson.rera[0]);
        }

        const headerResponse = await fetch(
          "https://www.buyindiahomes.in/api/header?website=smp-amberwoodrahatani.com"
        );
        const headerJson = await headerResponse.json();
        setHeaderData(headerJson);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  return (
    <>
      {/* Top Bar */}
      <div className="bg-amber-600 text-white py-2 hidden md:block">
        <div className="container mx-auto flex justify-between items-center px-4">
          <div className="flex items-center space-x-6">
            {headerData?.builder_name && (
              <span className="text-sm font-medium">
                <span className="font-semibold mr-1">Builder:</span> {headerData.builder_name}
              </span>
            )}
            {headerData?.location && (
              <span className="flex items-center text-sm">
                <MapPin size={14} className="mr-1" />
                {headerData.location} {headerData.sublocation && `- ${headerData.sublocation}`}
              </span>
            )}
          </div>
          <div className="flex items-center space-x-4">
            <a href="tel:+919876543210" className="flex items-center text-sm hover:text-amber-200">
              <Phone size={14} className="mr-1" />
              +91 98765 43210
            </a>
            {reraData && (
              <span className="text-sm flex items-center">
                <span className="font-semibold mr-1">RERA ID:</span> {reraData.rera_id}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <nav className="bg-amber-500 shadow-md sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center py-3">
            {/* Logo Section */}
            <div className="flex items-center space-x-3">
              {headerData?.logo && (
                <Image
                  src={headerData.logo}
                  alt={`${headerData.property_name || "SMP Amberwood"} Logo`}
                  width={100}
                  height={50}
                  className="object-contain"
                />
              )}
            </div>

            {/* Property Info (Desktop) */}
            <div className="hidden lg:block text-center">
              <h1 className="text-xl font-bold text-brown-900">
                {headerData?.property_name || "SMP Amberwood"}
              </h1>
              <div className="flex items-center justify-center space-x-4 text-sm text-gray-800 mt-1">
                {headerData?.property_type_price_range_text && (
                  <span>{headerData.property_type_price_range_text}</span>
                )}
                {headerData?.property_area_min_max && (
                  <>
                    <span className="h-4 w-px bg-gray-300"></span>
                    <span>{headerData.property_area_min_max}</span>
                  </>
                )}
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center">
              <div className="flex space-x-6 text-white font-medium mr-4">
                <Link href="/" className="hover:text-gray-200 transition-colors">Home</Link>
                <Link href="AmenitiesSection" className="hover:text-gray-200 transition-colors">AmenitiesSection</Link>
                <Link href="/" className="hover:text-gray-200 transition-colors">Floor Plans</Link>
                <Link href="/" className="hover:text-gray-200 transition-colors">Gallery</Link>
                <Link href="/" className="hover:text-gray-200 transition-colors">Amenities</Link>
                <Link href="/" className="hover:text-gray-200 transition-colors">Contact</Link>
              </div>

              {/* RERA Button */}
              {reraData && (
                <div className="relative">
                  <button
                    onClick={() => setShowReraDetails(!showReraDetails)}
                    className="flex items-center bg-amber-700 hover:bg-amber-800 text-white px-4 py-2 rounded transition-colors"
                  >
                    MahaRERA <ChevronDown size={16} className="ml-1" />
                  </button>

                  {showReraDetails && (
                    <div className="absolute right-0 mt-2 w-64 bg-white rounded-md shadow-lg z-10 p-4 border border-gray-200">
                      <h3 className="font-bold text-amber-700 border-b pb-2 mb-2">RERA Details</h3>
                      <p className="text-sm mb-1"><span className="font-semibold">Phase:</span> {reraData.phase_name}</p>
                      <p className="text-sm mb-1"><span className="font-semibold">RERA ID:</span> {reraData.rera_id}</p>
                      <p className="text-sm mb-1"><span className="font-semibold">Completion:</span> {reraData.completion_date}</p>
                      <a
                        href={reraData.rera_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="mt-2 block text-center bg-amber-600 text-white py-1 rounded text-sm hover:bg-amber-700 transition-colors"
                      >
                        View on MahaRERA Website
                      </a>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden focus:outline-none bg-amber-600 p-2 rounded-md"
              aria-label="Toggle menu"
            >
              {isOpen ? <X size={24} className="text-white" /> : <Menu size={24} className="text-white" />}
            </button>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Navbar;
