"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";

interface Blog {
  id: number;
  post_title: string;
  post_content_short: string;
  post_photo: string;
  post_slug: string;
  created_at: string;
}

const BlogList = () => {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const response = await fetch(
          "https://www.buyindiahomes.in/api/blogs?website=smp-amberwoodrahatani.com"
        );
        if (!response.ok) {
          throw new Error("Failed to fetch blogs");
        }
        const data = await response.json();
        setBlogs(data.blogs || []);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchBlogs();
  }, []);

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  if (loading)
    return (
      <div className="flex justify-center items-center h-64 bg-amber-50">
        <div className="relative w-20 h-20">
          <div className="absolute top-0 left-0 w-full h-full border-8 border-amber-200 rounded-full animate-ping opacity-75"></div>
          <div className="absolute top-2 left-2 w-16 h-16 border-4 border-t-amber-600 border-r-transparent border-b-transparent border-l-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    );

  if (error)
    return (
      <div className="bg-red-50 p-8 rounded-lg max-w-2xl mx-auto my-12">
        <p className="text-center text-red-600 font-semibold flex items-center justify-center">
          <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
          </svg>
          {error}
        </p>
      </div>
    );

  // Format date function
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  return (
    <section className="py-16 bg-gradient-to-br from-amber-100 via-white to-amber-300">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold tracking-widest text-amber-600 uppercase mb-2">Our Insights</h2>
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 leading-tight">
            Latest from <span className="text-amber-600">Our Blog</span>
          </h1>
          <div className="w-24 h-1 bg-amber-600 mx-auto mt-4 rounded-full"></div>
        </div>

        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {blogs.map((blog) => (
            <motion.div
              key={blog.id}
              variants={itemVariants}
              className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className="relative overflow-hidden h-56">
                <img
                  src={blog.post_photo || 'https://via.placeholder.com/600x400/amber/white?text=Blog+Image'}
                  alt={blog.post_title}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>
              
              <div className="p-6 relative">
                {blog.created_at && (
                  <span className="absolute -top-5 right-6 bg-amber-500 text-white text-xs font-semibold px-3 py-1 rounded-full shadow-md">
                    {formatDate(blog.created_at)}
                  </span>
                )}
                
                <h2 className="text-xl font-bold text-gray-800 mb-3 line-clamp-2 group-hover:text-amber-600 transition-colors duration-300">
                  {blog.post_title}
                </h2>
                
                <p className="text-gray-600 mt-3 line-clamp-3 text-sm">
                  {blog.post_content_short}
                </p>
                
                <div className="mt-6 flex justify-between items-center">
                  <a
                    href={`https://smp-amberwoodrahatani.com/blog/${blog.post_slug}`}
                    className="inline-flex items-center text-amber-600 font-semibold group-hover:text-amber-700 transition-colors duration-300"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Read Article
                    <svg className="w-4 h-4 ml-2 transform group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                    </svg>
                  </a>
                  
                  <div className="flex space-x-2">
                    <button className="p-2 text-gray-400 hover:text-amber-600 transition-colors duration-300">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path d="M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z"></path>
                      </svg>
                    </button>
                    <button className="p-2 text-gray-400 hover:text-red-500 transition-colors duration-300">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd"></path>
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
        
        {blogs.length === 0 && !loading && !error && (
          <div className="bg-amber-50 p-8 rounded-lg text-center">
            <svg className="w-16 h-16 text-amber-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
            </svg>
            <h3 className="text-xl font-medium text-gray-700">No blog posts found</h3>
            <p className="text-gray-500 mt-2">Check back later for new content!</p>
          </div>
        )}
        
        {blogs.length > 0 && (
          <div className="text-center mt-12">
            <a 
              href="https://smp-amberwoodrahatani.com/blogs" 
              className="inline-flex items-center px-6 py-3 bg-amber-500 text-white font-semibold rounded-full shadow-lg hover:bg-amber-600 transition duration-300 transform hover:scale-105"
              target="_blank"
              rel="noopener noreferrer"
            >
              View All Blog Posts
              <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3"></path>
              </svg>
            </a>
          </div>
        )}
      </div>
    </section>
  );
};

export default BlogList;