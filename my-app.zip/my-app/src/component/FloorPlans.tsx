"use client";

import { useEffect, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Autoplay } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";

interface FloorPlan {
  id: number;
  layout_name: string;
  layout_image: string;
}

const FloorPlans = () => {
  const [floorPlans, setFloorPlans] = useState<FloorPlan[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("https://www.buyindiahomes.in/api/floor-layout?website=smp-amberwoodrahatani.com")
      .then((response) => response.json())
      .then((data) => {
        if (data.Floor_plans) {
          setFloorPlans(data.Floor_plans);
        }
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching floor plans:", error);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen text-xl font-semibold text-amber-700">
        Loading floor plans...
      </div>
    );
  }

  return (
    <section className="py-16 bg-gradient-to-br from-amber-100 via-white to-amber-300 min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Heading */}
        <h2 className="text-4xl font-extrabold text-center text-amber-700 mb-12 relative">
          Floor Plans
          <span className="block w-24 h-1 bg-amber-700 mx-auto mt-3 rounded-full"></span>
        </h2>

        {/* Swiper Slider */}
        <Swiper
          modules={[Navigation, Autoplay]}
          slidesPerView={1}
          spaceBetween={20}
          navigation
          autoplay={{ delay: 3000, disableOnInteraction: false }}
          breakpoints={{
            640: { slidesPerView: 2 },
            1024: { slidesPerView: 3 },
          }}
          className="px-4"
        >
          {floorPlans.map((plan) => (
            <SwiperSlide key={plan.id}>
              <div className="bg-amber-400 shadow-lg rounded-2xl overflow-hidden transition transform hover:scale-105 hover:shadow-xl">
                <img
                  src={plan.layout_image}
                  alt={plan.layout_name}
                  className="w-full h-64 object-cover"
                />
                <div className="p-6 text-center">
                  <h3 className="text-2xl font-semibold text-gray-900">{plan.layout_name}</h3>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>

        {/* Custom Swiper Navigation */}
        <div className="mt-6 flex justify-center gap-4">
          <button className="swiper-button-prev-custom bg-amber-700 text-white px-4 py-2 rounded-full shadow-lg hover:bg-amber-800 transition duration-300">
            ← Prev
          </button>
          <button className="swiper-button-next-custom bg-amber-700 text-white px-4 py-2 rounded-full shadow-lg hover:bg-amber-800 transition duration-300">
            Next →
          </button>
        </div>
      </div>
    </section>
  );
};

export default FloorPlans;
