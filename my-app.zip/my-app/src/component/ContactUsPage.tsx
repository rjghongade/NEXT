"use client";

import { useEffect, useState } from "react";

interface ContactUs {
  name: string;
  detail: string;
  contact_phone: string | null;
  contact_email: string | null;
  contact_address: string | null;
  contact_map: string;
}

const ContactUsPage = () => {
  const [contact, setContact] = useState<ContactUs | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  useEffect(() => {
    const fetchContactInfo = async () => {
      try {
        const response = await fetch(
          "https://www.buyindiahomes.in/api/contact-us?website=smp-amberwoodrahatani.com"
        );
        if (!response.ok) {
          throw new Error("Failed to fetch contact details");
        }
        const data = await response.json();
        setContact(data.contact_us);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchContactInfo();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    alert("Thank you! Your message has been sent.");
    setFormData({ name: "", email: "", phone: "", message: "" });
  };

  if (loading) return <p className="text-center text-gray-500 py-10">Loading contact details...</p>;
  if (error) return <p className="text-center text-red-500 py-10">Error: {error}</p>;

  return (
    <section className="w-full min-h-screen bg-gradient-to-b from-amber-500 to-amber-700 py-12">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <h1 className="text-4xl font-extrabold text-white text-center mb-8">{contact?.name || "Contact Us"}</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Contact Form */}
          <div className="bg-gradient-to-br from-amber-100 via-white to-amber-300 shadow-lg rounded-lg p-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">Get in Touch</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-gray-700 font-medium">Full Name</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full mt-1 p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                  placeholder="Enter your full name"
                />
              </div>
              <div>
                <label className="text-gray-700 font-medium">Email Address</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full mt-1 p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                  placeholder="Enter your email"
                />
              </div>
              <div>
                <label className="text-gray-700 font-medium">Phone Number</label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                  className="w-full mt-1 p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                  placeholder="Enter your phone number"
                />
              </div>
              <div>
                <label className="text-gray-700 font-medium">Your Message</label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={4}
                  className="w-full mt-1 p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500"
                  placeholder="Type your message here..."
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full bg-amber-600 text-white font-semibold py-3 rounded-md hover:bg-amber-700 transition duration-300"
              >
                Send Message
              </button>
            </form>
          </div>

          {/* Contact Info & Map */}
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-amber-100 via-white to-amber-300 shadow-lg rounded-lg p-6">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4">Our Contact Details</h2>
              <p className="text-gray-600 mb-4" dangerouslySetInnerHTML={{ __html: contact?.detail || "" }} />

              {contact?.contact_phone && (
                <p className="text-lg">
                  📞 <span className="font-semibold text-gray-800">Phone:</span>
                  <a href={`tel:${contact.contact_phone}`} className="text-amber-600 hover:underline ml-2">
                    {contact.contact_phone}
                  </a>
                </p>
              )}

              {contact?.contact_email && (
                <p className="text-lg">
                  📧 <span className="font-semibold text-gray-800">Email:</span>
                  <a href={`mailto:${contact.contact_email}`} className="text-amber-600 hover:underline ml-2">
                    {contact.contact_email}
                  </a>
                </p>
              )}

              {contact?.contact_address && (
                <p className="text-lg">
                  📍 <span className="font-semibold text-gray-800">Address:</span>
                  <span className="ml-2">{contact.contact_address}</span>
                </p>
              )}
            </div>

            {contact?.contact_map && (
              <div className="bg-gradient-to-br from-amber-100 via-white to-amber-300 shadow-lg rounded-lg overflow-hidden">
                <h2 className="text-xl font-semibold text-gray-800 px-6 pt-6">📍 Find Us on the Map</h2>
                <div
                  className="border rounded-md mt-4"
                  dangerouslySetInnerHTML={{ __html: contact.contact_map }}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactUsPage;
