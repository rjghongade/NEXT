(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_aaf7d535._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_aaf7d535._.js",
  "chunks": [
    "static/chunks/[root of the server]__140ccadf._.css",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_023ece29._.js",
    "static/chunks/src_component_37bb4c83._.js",
    "static/chunks/node_modules_next_b7549175._.js",
    "static/chunks/node_modules_react-icons_fi_index_mjs_9cbf4bb1._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
    "static/chunks/node_modules_framer-motion_dist_es_0fad660f._.js",
    "static/chunks/node_modules_0ce48efd._.js"
  ],
  "source": "dynamic"
});
