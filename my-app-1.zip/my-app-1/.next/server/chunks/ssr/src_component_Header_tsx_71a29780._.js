module.exports = {

"[project]/src/component/Header.tsx [app-rsc] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_component_Header_tsx_c3871670._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/component/Header.tsx [app-rsc] (ecmascript, next/dynamic entry)");
    });
});
}}),

};